<style>
/* Import Google Fonts */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap');

/* Sidebar Styles */
.sidebar {
    width: 230px;
    background-color: #482500;
    color: white;
    display: flex;
    flex-direction: column;
    position: relative;
    min-height: 100vh;
    font-family: 'Poppins', sans-serif;
}

.logo-container {
    padding: 30px 20px;
    text-align: center;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.logo-link {
    display: inline-block;
    transition: all 0.3s ease;
    text-decoration: none;
}

.logo-link:hover {
    transform: scale(1.05);
    opacity: 0.9;
}

.logo-image {
    height: 45px;
    margin-bottom: 8px;
    transition: all 0.3s ease;
}

.logo-text {
    font-size: 28px;
    font-weight: 400;
    font-style: italic;
    color: white;
    text-decoration: none;
    font-family: 'Poppins', sans-serif;
    display: block;
    margin-bottom: 8px;
}

.logo-underline {
    width: 80%;
    height: 2px;
    background-color: white;
    margin: 0 auto;
}

.nav-menu {
    flex: 1;
    padding: 40px 0;
}

.nav-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 18px 30px;
    color: white;
    text-decoration: none;
    font-size: 16px;
    font-weight: 500;
    font-family: 'Poppins', sans-serif;
    transition: all 0.3s ease;
    border: none;
    background: none;
    cursor: pointer;
    width: 100%;
    text-align: left;
    position: relative;
    margin-bottom: 8px;
}

.nav-item:hover {
    background-color: rgba(255, 255, 255, 0.1);
}

.nav-item.active {
    background-color: #F5F0E8;
    color: #8B4513;
    font-weight: 600;
    border-radius: 25px 0 0 25px;
    margin-right: 15px;
}

.nav-item.active::before {
    content: '';
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    width: 8px;
    height: 8px;
    background-color: #8B4513;
    border-radius: 50%;
}

.nav-item.active .nav-icon {
    filter: brightness(0) saturate(100%) invert(36%) sepia(25%) saturate(1467%) hue-rotate(13deg) brightness(93%) contrast(96%);
}

.nav-icon {
    width: 20px;
    height: 20px;
    filter: brightness(0) saturate(100%) invert(100%) sepia(0%) saturate(7500%) hue-rotate(109deg) brightness(107%) contrast(107%);
}

.nav-text {
    margin-left: 8px;
}

.logout-container {
    padding: 20px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.logout-form {
    width: 100%;
}

.logout-btn {
    display: flex;
    align-items: center;
    gap: 10px;
    color: white;
    text-decoration: none;
    font-size: 16px;
    font-weight: 500;
    font-family: 'Poppins', sans-serif;
    padding: 12px 15px;
    border-radius: 8px;
    transition: all 0.3s ease;
    border: none;
    background: none;
    cursor: pointer;
    width: 100%;
}

.logout-btn:hover {
    background-color: rgba(255, 255, 255, 0.1);
}

.logout-icon {
    font-size: 18px;
}

/* Responsive Design */
@media (max-width: 1024px) {
    .sidebar {
        width: 200px;
    }
}

@media (max-width: 768px) {
    .sidebar {
        width: 100%;
        height: auto;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        padding: 15px 20px;
        min-height: auto;
    }

    .logo-container {
        padding: 0;
        border: none;
        margin-right: 20px;
    }

    .logo-image {
        height: 35px;
        margin-bottom: 0;
    }

    .logo-text {
        display: none;
    }

    .logo-underline {
        display: none;
    }

    .nav-menu {
        display: flex;
        gap: 20px;
        padding: 0;
        flex: 1;
        justify-content: center;
    }

    .nav-item {
        padding: 10px 15px;
        border-radius: 20px;
        margin: 0;
        flex-direction: column;
        gap: 5px;
        min-width: 80px;
        text-align: center;
    }

    .nav-item.active {
        border-radius: 20px;
        margin-right: 0;
    }

    .nav-text {
        margin-left: 0;
        font-size: 12px;
    }

    .logout-container {
        padding: 0;
        border: none;
    }

    .logout-btn {
        padding: 10px;
        font-size: 14px;
    }
}
</style>

<div class="sidebar">
    <div class="logo-container">
        <a href="<?php echo e(route('home')); ?>" class="logo-link">
            <img src="<?php echo e(asset('logoputih.png')); ?>" alt="Niranta Logo" class="logo-image">
        </a>
    </div>

    <nav class="nav-menu">
        <a href="<?php echo e(route('admin.products')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.products') ? 'active' : ''); ?>">
            <img src="<?php echo e(asset('products.png')); ?>" alt="Products" class="nav-icon">
            <span class="nav-text">Products</span>
        </a>
        <a href="<?php echo e(route('admin.recipes')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.recipes') ? 'active' : ''); ?>">
            <img src="<?php echo e(asset('resep.svg')); ?>" alt="Recipes" class="nav-icon">
            <span class="nav-text">Recipes</span>
        </a>
        <a href="<?php echo e(route('admin.blogs')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.blogs') ? 'active' : ''); ?>">
            <img src="<?php echo e(asset('blog.svg')); ?>" alt="Blogs" class="nav-icon">
            <span class="nav-text">Blogs</span>
        </a>
    </nav>

    <div class="logout-container">
        <form method="POST" action="<?php echo e(route('logout')); ?>" class="logout-form">
            <?php echo csrf_field(); ?>
            <button type="submit" class="logout-btn">
                <span class="logout-icon">🚪</span>
                Log Out
            </button>
        </form>
    </div>
</div>
<?php /**PATH D:\niranta\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>