<?php

require_once 'vendor/autoload.php';

$app = require_once 'bootstrap/app.php';
$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use App\Models\Blog;
use App\Services\GoogleTranslateService;

echo "Updating blog translations using DB queries...\n";

$translateService = new GoogleTranslateService();
$blogs = Blog::all();

echo "Found " . $blogs->count() . " blogs to process\n";

foreach ($blogs as $blog) {
    echo "Processing blog: {$blog->judul_blog}\n";
    
    try {
        // Translate judul blog
        $translatedTitle = $translateService->translate($blog->judul_blog, 'en', 'id');
        
        // Translate excerpt
        $translatedExcerpt = $translateService->translate($blog->excerpt, 'en', 'id');
        
        // Translate content
        $translatedContent = $translateService->translate($blog->content, 'en', 'id');

        // English translation
        \DB::table('blog_translations')->updateOrInsert(
            [
                'blog_id' => $blog->id,
                'locale' => 'en'
            ],
            [
                'judul_blog' => $translatedTitle,
                'excerpt' => $translatedExcerpt,
                'content' => $translatedContent,
                'updated_at' => now(),
                'created_at' => now()
            ]
        );

        // Indonesian original
        \DB::table('blog_translations')->updateOrInsert(
            [
                'blog_id' => $blog->id,
                'locale' => 'id'
            ],
            [
                'judul_blog' => $blog->judul_blog,
                'excerpt' => $blog->excerpt,
                'content' => $blog->content,
                'updated_at' => now(),
                'created_at' => now()
            ]
        );
        
        echo "✓ Translated: {$blog->judul_blog} → {$translatedTitle}\n";
        
        // Small delay to avoid API rate limits
        sleep(1);
        
    } catch (\Exception $e) {
        echo "✗ Error translating {$blog->judul_blog}: " . $e->getMessage() . "\n";
    }
}

echo "Blog translation update completed!\n";
