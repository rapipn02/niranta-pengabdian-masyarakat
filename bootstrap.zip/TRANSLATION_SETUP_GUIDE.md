# Panduan Setup Sistem Terjemahan

## Navbar Mobile Telah Diperbaiki ✅
- Menambahkan menu hamburger fungsional dengan overlay
- Navigasi mobile sekarang bekerja dengan baik dengan animasi yang halus
- Hamburger berubah menjadi X ketika dibuka
- Menu tertutup ketika mengklik di luar atau pada item menu

## Implementasi Sistem Terjemahan

### 1. Terjemahan Statis (Manual - untuk UI yang sudah ada)
- File bahasa dibuat di `lang/id/messages.php` dan `lang/en/messages.php`
- Mencakup navigasi, halaman home, halaman contact, footer, dan teks umum
- Menggunakan fungsi bawaan Laravel `__()`

### 2. Terjemahan Dinamis (Google API - untuk konten admin)
- Terjemahan otomatis untuk produk, resep, dan blog
- Menggunakan Google Translate API untuk terjemahan real-time
- Cache terjemahan untuk menghindari panggilan API berulang

## Instruksi Setup

### Langkah 1: Jalankan Composer Updat e
```bash
composer dump-autoload
```

### Langkah 2: Konfigurasi Google Translate API
1. Pergi ke [Google Cloud Console](https://console.cloud.google.com)
2. Buat proyek baru atau pilih yang sudah ada
3. Aktifkan "Cloud Translation API"
4. Buat kredensial (API Key)
5. Tambahkan ke file `.env` Anda:
```env
GOOGLE_TRANSLATE_API_KEY=kunci_api_google_anda_disini
APP_LOCALE=id
APP_FALLBACK_LOCALE=id
```

### Langkah 3: Update Konfigurasi Bahasa
Di `config/app.php`, pastikan:
```php
'locale' => env('APP_LOCALE', 'id'),
'fallback_locale' => env('APP_FALLBACK_LOCALE', 'id'),
```

## Cara Kerja

### Terjemahan Statis
- Menggunakan sintaks `{{ __('messages.nav.home') }}`
- Otomatis beralih antara Bahasa Indonesia dan Inggris
- Tidak memerlukan panggilan API

### Terjemahan Dinamis  
- Untuk konten yang ditambahkan admin (produk, resep, blog)
- Menandai konten dengan atribut `data-translate`
- JavaScript secara otomatis menerjemahkan ketika bahasa diubah
- Contoh: `{!! translateDynamic($product->nama_produk) !!}`

## Contoh Penggunaan

### Di Template Blade (Statis):
```blade
<h1>{{ __('messages.home.hero_title') }}</h1>
<p>{{ __('messages.home.hero_description') }}</p>
```

### Untuk Konten Dinamis:
```blade
<h2 data-translate="true">{{ $recipe->nama_resep }}</h2>
<p data-translate="true">{{ $recipe->deskripsi }}</p>
```

### Pergantian Bahasa:
- Klik ikon globe di footer
- Otomatis beralih antara Bahasa Indonesia ↔ Inggris
- Halaman reload dengan bahasa baru

## Struktur File
```
lang/
├── id/
│   └── messages.php (Terjemahan Bahasa Indonesia)
└── en/
    └── messages.php (Terjemahan Bahasa Inggris)

app/
├── Http/
│   ├── Controllers/
│   │   └── TranslationController.php
│   └── Middleware/
│       └── SetLanguage.php
└── helpers.php (Fungsi helper terjemahan)
```

## API Endpoints
- `GET /translate/switch/{locale}` - Ganti bahasa
- `POST /translate/dynamic` - Terjemahkan konten dinamis
- `GET /translate/content/{type}/{id}/{field}/{language}` - Dapatkan konten terjemahan

## Fitur
✅ Navbar mobile responsif dengan menu hamburger
✅ Terjemahan statis untuk elemen UI
✅ Terjemahan dinamis untuk konten admin
✅ Pergantian bahasa melalui tombol footer
✅ Fallback ke bahasa asli jika terjemahan gagal
✅ Caching untuk meminimalkan panggilan API
✅ URL yang SEO-friendly tetap sama

## Testing
1. Test navbar mobile di berbagai ukuran layar
2. Ganti bahasa menggunakan tombol globe di footer
3. Tambahkan konten baru di admin dan verifikasi terjemahan
4. Periksa konfigurasi API key di browser console
