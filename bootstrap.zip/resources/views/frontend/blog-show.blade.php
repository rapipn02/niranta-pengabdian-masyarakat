@extends('frontend.layouts.app')

@section('content')
<!-- Blog Detail Section -->
<section style="
    background-color: #F2ECE0;
    padding: 120px 0 80px 0;
    min-height: 100vh;
">
    <div style="
        max-width: 1000px;
        margin: 0 auto;
        padding: 0 20px;
    ">
        <!-- Back Button -->
        <div style="margin-bottom: 40px;">
            <a href="{{ route('blogs') }}" style="
                display: inline-flex;
                align-items: center;
                background: #8B4513;
                color: white;
                text-decoration: none;
                padding: 12px 20px;
                border-radius: 10px;
                font-family: 'Inter', sans-serif;
                font-size: 14px;
                font-weight: 500;
                transition: background 0.3s ease;
            " onmouseover="this.style.background='#6D3410'" onmouseout="this.style.background='#8B4513'">
                ← Back to Blogs
            </a>
        </div>

        <!-- Blog Content Card -->
        <div style="
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        ">
            <!-- Blog Header Image -->
            <div style="
                height: 400px;
                background-size: cover;
                background-position: center;
                position: relative;
                @if($blog->image && file_exists(public_path('storage/' . $blog->image)))
                    background-image: url('{{ asset('storage/' . $blog->image) }}');
                @else
                    background-image: url('{{ asset('blog1.png') }}');
                @endif
            ">
                <!-- Overlay for better text readability -->
                <div style="
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    right: 0;
                    background: linear-gradient(transparent, rgba(0, 0, 0, 0.7));
                    padding: 40px;
                    color: white;
                ">
                    <h1 style="
                        font-family: 'Inter', sans-serif;
                        font-size: 2.5rem;
                        font-weight: bold;
                        margin: 0;
                        line-height: 1.2;
                        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
                    ">{{ $blog->getTranslatedTitle() }}</h1>
                </div>
            </div>

            <!-- Blog Meta & Content -->
            <div style="padding: 40px;">
                <!-- Blog Meta Information -->
                <div style="
                    display: flex;
                    align-items: center;
                    gap: 20px;
                    margin-bottom: 30px;
                    padding-bottom: 20px;
                    border-bottom: 2px solid #F2ECE0;
                ">
                    <div style="
                        display: flex;
                        align-items: center;
                        gap: 8px;
                        font-family: 'Inter', sans-serif;
                        color: #8B4513;
                        font-weight: 500;
                    ">
                        <svg style="width: 16px; height: 16px;" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z"/>
                        </svg>
                        {{ $blog->tanggal_upload->format('d M Y') }}
                    </div>
                    
                    <div style="
                        display: flex;
                        align-items: center;
                        gap: 8px;
                        font-family: 'Inter', sans-serif;
                        color: #8B4513;
                        font-weight: 500;
                    ">
                        <svg style="width: 16px; height: 16px;" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                        </svg>
                        {{ $blog->author ?? 'Admin' }}
                    </div>
                </div>

                <!-- Blog Excerpt -->
                @if($blog->getTranslatedExcerpt())
                <div style="
                    background: #F9F7F4;
                    padding: 25px;
                    border-radius: 15px;
                    border-left: 5px solid #8B4513;
                    margin-bottom: 30px;
                ">
                    <p style="
                        font-family: 'Inter', sans-serif;
                        font-size: 1.1rem;
                        color: #5D4E37;
                        line-height: 1.6;
                        margin: 0;
                        font-style: italic;
                    ">{{ $blog->getTranslatedExcerpt() }}</p>
                </div>
                @endif

                <!-- Blog Content -->
                <div style="
                    font-family: 'Inter', sans-serif;
                    line-height: 1.8;
                    color: #333;
                    font-size: 1rem;
                " class="blog-content">
                    {!! nl2br(e($blog->getTranslatedContent())) !!}
                </div>

                <!-- Tags or Categories (if you have them) -->
                <div style="
                    margin-top: 40px;
                    padding-top: 30px;
                    border-top: 2px solid #F2ECE0;
                ">
                    <div style="
                        display: inline-block;
                        background: #8B4513;
                        color: white;
                        padding: 8px 16px;
                        border-radius: 20px;
                        font-size: 14px;
                        font-weight: 500;
                    ">
                        Blog Niranta
                    </div>
                </div>
            </div>
        </div>

        <!-- Related Blogs -->
        @if($relatedBlogs && $relatedBlogs->count() > 0)
        <div style="margin-top: 60px;">
            <h2 style="
                font-family: 'Inter', sans-serif;
                font-size: 2rem;
                font-weight: bold;
                color: #8B4513;
                margin: 0 0 40px 0;
                text-align: center;
            ">Blog Lainnya</h2>
            
            <div style="
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 30px;
            ">
                @foreach($relatedBlogs as $related)
                    <div style="
                        background: white;
                        border-radius: 15px;
                        overflow: hidden;
                        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
                        transition: transform 0.3s ease;
                        cursor: pointer;
                    " onmouseover="this.style.transform='translateY(-5px)'" onmouseout="this.style.transform='translateY(0)'"
                       onclick="window.location.href='{{ route('blogs.show', '') }}/' + {{ $related->id }}">
                        <div style="
                            height: 200px;
                            background-size: cover;
                            background-position: center;
                            @if($related->image && file_exists(public_path('storage/' . $related->image)))
                                background-image: url('{{ asset('storage/' . $related->image) }}');
                            @else
                                background-image: url('{{ asset('blog1.png') }}');
                            @endif
                        "></div>
                        <div style="padding: 20px;">
                            <h3 style="
                                font-family: 'Inter', sans-serif;
                                font-size: 1.1rem;
                                font-weight: 600;
                                color: #8B4513;
                                margin: 0 0 10px 0;
                                line-height: 1.3;
                            ">{{ $related->getTranslatedTitle() }}</h3>
                            <p style="
                                color: #666;
                                font-size: 0.9rem;
                                margin: 0 0 10px 0;
                                line-height: 1.5;
                            ">{{ Str::limit($related->getTranslatedExcerpt() ?? $related->getTranslatedContent(), 100) }}</p>
                            <div style="
                                font-size: 0.8rem;
                                color: #8B4513;
                                font-weight: 500;
                            ">{{ $related->tanggal_upload->format('d M Y') }}</div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
        @endif
    </div>
</section>

<!-- Custom CSS for Blog Content -->
<style>
    .blog-content p {
        margin-bottom: 20px;
    }
    
    .blog-content h2, .blog-content h3, .blog-content h4 {
        color: #8B4513;
        font-weight: 600;
        margin: 30px 0 15px 0;
    }
    
    .blog-content h2 {
        font-size: 1.5rem;
    }
    
    .blog-content h3 {
        font-size: 1.3rem;
    }
    
    .blog-content ul, .blog-content ol {
        margin: 20px 0;
        padding-left: 30px;
    }
    
    .blog-content li {
        margin-bottom: 8px;
        line-height: 1.6;
    }
    
    .blog-content strong {
        color: #8B4513;
        font-weight: 600;
    }
    
    @media (max-width: 768px) {
        .blog-content {
            font-size: 0.95rem;
        }
        
        .blog-content h1 {
            font-size: 2rem !important;
        }
        
        .blog-content h2 {
            font-size: 1.3rem;
        }
    }
</style>
@endsection
