<?php

require_once 'vendor/autoload.php';

$app = require_once 'bootstrap/app.php';
$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use App\Models\Recipe;

echo "Recipe data inspection...\n";

$recipe = Recipe::first();

if ($recipe) {
    echo "Recipe: {$recipe->nama_resep}\n";
    echo "Deskripsi: {$recipe->deskripsi}\n";
    echo "Bahan type: " . gettype($recipe->bahan) . "\n";
    echo "Bahan: " . json_encode($recipe->bahan) . "\n";
    echo "Cara membuat type: " . gettype($recipe->cara_membuat) . "\n";
    echo "Cara membuat: {$recipe->cara_membuat}\n";
} else {
    echo "No recipes found\n";
}
