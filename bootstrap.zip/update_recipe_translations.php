<?php

require_once 'vendor/autoload.php';

$app = require_once 'bootstrap/app.php';
$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use App\Models\Recipe;
use App\Services\GoogleTranslateService;

echo "Updating recipe translations using DB queries...\n";

$translateService = new GoogleTranslateService();
$recipes = Recipe::all();

echo "Found " . $recipes->count() . " recipes to process\n";

foreach ($recipes as $recipe) {
    echo "Processing recipe: {$recipe->nama_resep}\n";
    
    try {
        // Translate nama resep
        $translatedName = $translateService->translate($recipe->nama_resep, 'en', 'id');
        
        // Translate deskripsi
        $translatedDescription = $translateService->translate($recipe->deskripsi, 'en', 'id');
        
        // Translate cara membuat (convert string to array first)
        $caraMembuatArray = array_filter(array_map('trim', explode("\n", $recipe->cara_membuat)));
        $translatedCaraMembuat = $translateService->translateArray($caraMembuatArray, 'en', 'id');
        
        // Translate bahan (array)
        $translatedBahan = $translateService->translateArray($recipe->bahan, 'en', 'id');

        // English translation
        \DB::table('recipe_translations')->updateOrInsert(
            [
                'recipe_id' => $recipe->id,
                'locale' => 'en'
            ],
            [
                'nama_resep' => $translatedName,
                'deskripsi' => $translatedDescription,
                'bahan' => json_encode($translatedBahan),
                'cara_membuat' => json_encode($translatedCaraMembuat),
                'updated_at' => now(),
                'created_at' => now()
            ]
        );

        // Indonesian original
        $originalCaraMembuatArray = array_filter(array_map('trim', explode("\n", $recipe->cara_membuat)));
        \DB::table('recipe_translations')->updateOrInsert(
            [
                'recipe_id' => $recipe->id,
                'locale' => 'id'
            ],
            [
                'nama_resep' => $recipe->nama_resep,
                'deskripsi' => $recipe->deskripsi,
                'bahan' => json_encode($recipe->bahan),
                'cara_membuat' => json_encode($originalCaraMembuatArray),
                'updated_at' => now(),
                'created_at' => now()
            ]
        );
        
        echo "✓ Translated: {$recipe->nama_resep} → {$translatedName}\n";
        
        // Small delay to avoid API rate limits
        sleep(1);
        
    } catch (\Exception $e) {
        echo "✗ Error translating {$recipe->nama_resep}: " . $e->getMessage() . "\n";
    }
}

echo "Recipe translation update completed!\n";
