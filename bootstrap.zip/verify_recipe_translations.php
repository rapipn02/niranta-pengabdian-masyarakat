<?php

require_once 'vendor/autoload.php';

$app = require_once 'bootstrap/app.php';
$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();

echo "Recipe translations verification...\n";

$translations = \DB::table('recipe_translations')->get();

echo "Found " . $translations->count() . " recipe translations\n\n";

foreach ($translations as $translation) {
    echo "Recipe ID: {$translation->recipe_id}, Locale: {$translation->locale}\n";
    echo "Name: {$translation->nama_resep}\n";
    echo "Description: {$translation->deskripsi}\n";
    echo "Ingredients: {$translation->bahan}\n";
    echo "Instructions: {$translation->cara_membuat}\n";
    echo "---\n";
}
