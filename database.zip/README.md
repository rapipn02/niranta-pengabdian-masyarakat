# Product Profile Website

A fullstack Laravel website for product profile with multi-language support (Indonesian & English), featuring products, recipes, and blogs management.

## Features

### Frontend Features
- **Multi-language Support**: Indonesian (default) and English
- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Product Showcase**: Browse and view product details
- **Recipe Collection**: Browse and view cooking recipes
- **Blog System**: Read articles and tips
- **Contact Form**: Get in touch with the team
- **Hidden Admin Login**: Secure admin access at `/admin-login`

### Backend Features
- **Product Management**: Add, edit, delete products with multilingual content
- **Recipe Management**: Manage recipes with ingredients and instructions
- **Blog Management**: Create and manage blog posts
- **Multi-language Content**: Static content via language files, dynamic content via API translation
- **Authentication**: Laravel Breeze for admin authentication

### Language Implementation
- **Static Content**: Pre-written during development (stored in `lang/` directory)
- **Dynamic Content**: User-generated content translated via API during production

## Technology Stack

- **Framework**: Laravel 12.x
- **Frontend**: Blade Templates with Alpine.js and Tailwind CSS
- **Database**: SQLite (default) / MySQL
- **Authentication**: Laravel Breeze
- **Styling**: Tailwind CSS
- **Language**: Multi-language with Laravel Localization

## Installation

1. **Install PHP dependencies**
   ```bash
   composer install
   ```

2. **Install and build frontend assets**
   ```bash
   npm install
   npm run build
   ```

3. **Environment setup**
   ```bash
   cp .env.example .env
   php artisan key:generate
   ```

4. **Database setup**
   ```bash
   php artisan migrate
   ```

5. **Storage link**
   ```bash
   php artisan storage:link
   ```

6. **Serve the application**
   ```bash
   php artisan serve
   ```

## Usage

### Frontend Routes
- **Home**: `/`
- **Products**: `/products`
- **Recipes**: `/recipes`
- **Blogs**: `/blogs`
- **Contact**: `/contact`
- **Admin Login**: `/admin-login` (hidden)

### Language Switching
Add `?lang=id` or `?lang=en` to any URL to switch languages.

## File Structure
```
resources/views/frontend/
├── layouts/app.blade.php      # Main layout
├── partials/                  # Navigation & footer
├── components/                # Reusable cards
├── home.blade.php            # Homepage
├── products/                 # Product pages
├── recipes/                  # Recipe pages
├── blogs/                    # Blog pages
└── contact.blade.php         # Contact form
```

## Development Setup Complete ✅

The frontend structure is now ready for development with:
- ✅ Multi-language support (ID/EN)
- ✅ Responsive navigation with language switcher
- ✅ Product, Recipe, Blog components
- ✅ Contact form with validation
- ✅ Authentication system (Laravel Breeze)
- ✅ Database migrations
- ✅ Tailwind CSS styling
- ✅ Alpine.js interactivity

Ready for Figma design implementation!

## About Laravel

Laravel is a web application framework with expressive, elegant syntax. We believe development must be an enjoyable and creative experience to be truly fulfilling. Laravel takes the pain out of development by easing common tasks used in many web projects, such as:

- [Simple, fast routing engine](https://laravel.com/docs/routing).
- [Powerful dependency injection container](https://laravel.com/docs/container).
- Multiple back-ends for [session](https://laravel.com/docs/session) and [cache](https://laravel.com/docs/cache) storage.
- Expressive, intuitive [database ORM](https://laravel.com/docs/eloquent).
- Database agnostic [schema migrations](https://laravel.com/docs/migrations).
- [Robust background job processing](https://laravel.com/docs/queues).
- [Real-time event broadcasting](https://laravel.com/docs/broadcasting).

Laravel is accessible, powerful, and provides tools required for large, robust applications.

## Learning Laravel

Laravel has the most extensive and thorough [documentation](https://laravel.com/docs) and video tutorial library of all modern web application frameworks, making it a breeze to get started with the framework.

You may also try the [Laravel Bootcamp](https://bootcamp.laravel.com), where you will be guided through building a modern Laravel application from scratch.

If you don't feel like reading, [Laracasts](https://laracasts.com) can help. Laracasts contains thousands of video tutorials on a range of topics including Laravel, modern PHP, unit testing, and JavaScript. Boost your skills by digging into our comprehensive video library.

## Laravel Sponsors

We would like to extend our thanks to the following sponsors for funding Laravel development. If you are interested in becoming a sponsor, please visit the [Laravel Partners program](https://partners.laravel.com).

### Premium Partners

- **[Vehikl](https://vehikl.com)**
- **[Tighten Co.](https://tighten.co)**
- **[Kirschbaum Development Group](https://kirschbaumdevelopment.com)**
- **[64 Robots](https://64robots.com)**
- **[Curotec](https://www.curotec.com/services/technologies/laravel)**
- **[DevSquad](https://devsquad.com/hire-laravel-developers)**
- **[Redberry](https://redberry.international/laravel-development)**
- **[Active Logic](https://activelogic.com)**

## Contributing

Thank you for considering contributing to the Laravel framework! The contribution guide can be found in the [Laravel documentation](https://laravel.com/docs/contributions).

## Code of Conduct

In order to ensure that the Laravel community is welcoming to all, please review and abide by the [Code of Conduct](https://laravel.com/docs/contributions#code-of-conduct).

## Security Vulnerabilities

If you discover a security vulnerability within Laravel, please send an e-mail to Taylor Otwell via [taylor@laravel.com](mailto:taylor@laravel.com). All security vulnerabilities will be promptly addressed.

## License

The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
