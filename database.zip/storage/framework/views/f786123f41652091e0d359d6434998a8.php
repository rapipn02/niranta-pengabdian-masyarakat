<!-- Scroll Down Indicator -->
<div id="scrollIndicator" style="
    position: fixed;
    bottom: 32px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 40;
    transition: all 0.3s ease-in-out;
    opacity: 1;
    pointer-events: auto;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    align-items: center;
" onclick="window.scrollToContent && window.scrollToContent()">
    <!-- Text Label -->
    <span style="
        color: white;
        font-size: 12px;
        font-weight: 500;
        letter-spacing: 1px;
        margin-bottom: 8px;
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
        font-family: 'Inter', sans-serif;
    ">SCROLL</span>
    
    <!-- Arrow Down Icon -->
    <div style="animation: bounce 2s infinite;">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.5));">
            <path d="M7 10L12 15L17 10" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    </div>
    
    <!-- Second Arrow for emphasis -->
    <div style="animation: bounce 2s infinite; animation-delay: 0.2s; margin-top: 4px;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.5));">
            <path d="M7 10L12 15L17 10" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    </div>
</div>

<!-- JavaScript for Scroll Indicator -->
<script>
    // Wait for DOM to be ready
    document.addEventListener('DOMContentLoaded', function() {
        let lastScrollTop = 0;
        const scrollIndicator = document.getElementById('scrollIndicator');
        
        if (!scrollIndicator) {
            console.log('Scroll indicator not found');
            return;
        }
        
        // Function to scroll to content area
        window.scrollToContent = function() {
            const contentSection = document.querySelector('.content-section') || document.querySelector('[data-content]');
            if (contentSection) {
                contentSection.scrollIntoView({ 
                    behavior: 'smooth',
                    block: 'start'
                });
            } else {
                // Fallback: scroll down by viewport height
                window.scrollBy({
                    top: window.innerHeight * 0.8,
                    behavior: 'smooth'
                });
            }
        }
        
        // Handle scroll visibility
        function handleScroll() {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            const windowHeight = window.innerHeight;
            const documentHeight = document.documentElement.scrollHeight;
            
            // Show indicator when at the very top (within 50px)
            if (scrollTop <= 50) {
                scrollIndicator.style.opacity = '1';
                scrollIndicator.style.pointerEvents = 'auto';
            }
            // Hide indicator when scrolled down more than 100px
            else if (scrollTop > 100) {
                scrollIndicator.style.opacity = '0';
                scrollIndicator.style.pointerEvents = 'none';
            }
            
            // Hide when near bottom of page
            if (scrollTop + windowHeight >= documentHeight - 100) {
                scrollIndicator.style.opacity = '0';
                scrollIndicator.style.pointerEvents = 'none';
            }
            
            lastScrollTop = scrollTop;
        }
        
        // Add scroll event listener
        window.addEventListener('scroll', handleScroll);
        
        // Initial check
        handleScroll();
        
        // Make sure indicator is visible initially
        scrollIndicator.style.opacity = '1';
        scrollIndicator.style.pointerEvents = 'auto';
        
        console.log('Scroll indicator initialized');
    });
</script>

<style>
    /* Enhanced animation for arrows */
    @keyframes bounce {
        0%, 20%, 53%, 80%, 100% {
            transform: translate3d(0,0,0);
        }
        40%, 43% {
            transform: translate3d(0,-8px,0);
        }
        70% {
            transform: translate3d(0,-4px,0);
        }
        90% {
            transform: translate3d(0,-2px,0);
        }
    }
    
    #scrollIndicator:hover {
        transform: translate(-50%, -5px) !important;
    }
</style>
<?php /**PATH D:\niranta\resources\views/frontend/partials/scroll-indicator.blade.php ENDPATH**/ ?>