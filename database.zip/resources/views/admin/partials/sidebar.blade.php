<style>
/* Import Google Fonts */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap');

/* Sidebar Styles */
.sidebar {
    width: 230px;
    background-color: #482500;
    color: white;
    display: flex;
    flex-direction: column;
    position: relative;
    min-height: 100vh;
    font-family: 'Poppins', sans-serif;
}

.logo-container {
    padding: 30px 20px;
    text-align: center;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.logo-link {
    display: inline-block;
    transition: all 0.3s ease;
    text-decoration: none;
}

.logo-link:hover {
    transform: scale(1.05);
    opacity: 0.9;
}

.logo-image {
    height: 45px;
    margin-bottom: 8px;
    transition: all 0.3s ease;
}

.logo-text {
    font-size: 28px;
    font-weight: 400;
    font-style: italic;
    color: white;
    text-decoration: none;
    font-family: 'Poppins', sans-serif;
    display: block;
    margin-bottom: 8px;
}

.logo-underline {
    width: 80%;
    height: 2px;
    background-color: white;
    margin: 0 auto;
}

.nav-menu {
    flex: 1;
    padding: 40px 0;
}

.nav-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 18px 30px;
    color: white;
    text-decoration: none;
    font-size: 16px;
    font-weight: 500;
    font-family: 'Poppins', sans-serif;
    transition: all 0.3s ease;
    border: none;
    background: none;
    cursor: pointer;
    width: 100%;
    text-align: left;
    position: relative;
    margin-bottom: 8px;
    justify-content: center;
}

.nav-item:hover {
    background-color: rgba(255, 255, 255, 0.1);
}

.nav-item.active {
    background-color: #F5F0E8;
    color: #8B4513;
    font-weight: 600;
    border-radius: 25px 0 0 25px;
    margin-right: 15px;
}

.nav-item.active::before {
    content: '';
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    width: 8px;
    height: 8px;
    background-color: #8B4513;
    border-radius: 50%;
}

.nav-text {
    margin-left: 0;
}

.logout-container {
    padding: 20px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.logout-form {
    width: 100%;
}

.logout-btn {
    display: flex;
    align-items: center;
    gap: 10px;
    color: white;
    text-decoration: none;
    font-size: 16px;
    font-weight: 500;
    font-family: 'Poppins', sans-serif;
    padding: 12px 15px;
    border-radius: 8px;
    transition: all 0.3s ease;
    border: none;
    background: none;
    cursor: pointer;
    width: 100%;
    justify-content: center;
}

.logout-btn:hover {
    background-color: rgba(255, 255, 255, 0.1);
}

/* Responsive Design */
@media (max-width: 1024px) {
    .sidebar {
        width: 200px;
    }
}

@media (max-width: 768px) {
    .sidebar {
        width: 100%;
        height: auto;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        padding: 15px 20px;
        min-height: auto;
        flex-wrap: nowrap;
    }

    .logo-container {
        padding: 0;
        border: none;
        margin-right: 15px;
        flex-shrink: 0;
    }

    .logo-image {
        height: 35px;
        margin-bottom: 0;
    }

    .logo-text {
        display: none;
    }

    .logo-underline {
        display: none;
    }

    .nav-menu {
        display: flex;
        gap: 15px;
        padding: 0;
        flex: 1;
        justify-content: center;
        overflow-x: auto;
    }

    .nav-item {
        padding: 8px 12px;
        border-radius: 20px;
        margin: 0;
        flex-direction: column;
        gap: 3px;
        min-width: 70px;
        text-align: center;
        flex-shrink: 0;
    }

    .nav-item.active {
        border-radius: 20px;
        margin-right: 0;
    }

    .nav-text {
        margin-left: 0;
        font-size: 11px;
    }

    .logout-container {
        padding: 0;
        border: none;
        flex-shrink: 0;
        margin-left: 15px;
    }

    .logout-btn {
        padding: 8px 12px;
        font-size: 12px;
        min-width: 60px;
        gap: 5px;
    }
}
</style>

<div class="sidebar">
    <div class="logo-container">
        <a href="{{ route('home') }}" class="logo-link">
            <img src="{{ asset('logoputih.png') }}" alt="Niranta Logo" class="logo-image">
        </a>
    </div>

    <nav class="nav-menu">
        <a href="{{ route('admin.products') }}" class="nav-item {{ request()->routeIs('admin.products') ? 'active' : '' }}">
            <span class="nav-text">Products</span>
        </a>
        <a href="{{ route('admin.recipes') }}" class="nav-item {{ request()->routeIs('admin.recipes') ? 'active' : '' }}">
            <span class="nav-text">Recipes</span>
        </a>
        <a href="{{ route('admin.blogs') }}" class="nav-item {{ request()->routeIs('admin.blogs') ? 'active' : '' }}">
            <span class="nav-text">Blogs</span>
        </a>
    </nav>

    <div class="logout-container">
        <form method="POST" action="{{ route('logout') }}" class="logout-form">
            @csrf
            <button type="submit" class="logout-btn">
                Log Out
            </button>
        </form>
    </div>
</div>
