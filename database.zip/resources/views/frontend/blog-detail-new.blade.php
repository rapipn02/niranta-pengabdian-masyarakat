@extends('frontend.layouts.app')

@section('content')
<!-- Blog Detail Section -->
<section style="
    background-color: #F2ECE0;
    padding: 120px 0 80px 0;
    min-height: 100vh;
">
    <div style="
        max-width: 800px;
        margin: 0 auto;
        padding: 0 20px;
    ">
        <!-- Blog Content Card -->
        <div style="
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 40px;
        ">
            <!-- Blog Image -->
            <div style="
                height: 300px;
                background-size: cover;
                background-position: center;
                position: relative;
                @if($blog->image && file_exists(public_path('storage/' . $blog->image)))
                    background-image: url('{{ asset('storage/' . $blog->image) }}');
                @else
                    background-image: url('{{ asset('makanan1.png') }}');
                @endif
            ">
                <!-- Image overlay if needed -->
                <div style="
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    right: 0;
                    background: linear-gradient(transparent, rgba(0, 0, 0, 0.3));
                    height: 100px;
                "></div>
            </div>

            <!-- Blog Content -->
            <div style="padding: 40px;">
                <!-- Blog Title -->
                <h1 style="
                    font-family: 'Inter', sans-serif;
                    font-size: 2rem;
                    font-weight: bold;
                    color: #2C1810;
                    margin: 0 0 20px 0;
                    line-height: 1.3;
                ">{{ $blog->judul_blog }}</h1>

                <!-- Blog Meta -->
                <div style="
                    display: flex;
                    gap: 20px;
                    margin-bottom: 30px;
                    padding-bottom: 20px;
                    border-bottom: 1px solid #f0f0f0;
                ">
                    <div style="
                        color: #888;
                        font-family: 'Inter', sans-serif;
                        font-size: 14px;
                    ">
                        <strong>{{ $blog->author ?? 'Admin' }}</strong>
                    </div>
                    <div style="
                        color: #888;
                        font-family: 'Inter', sans-serif;
                        font-size: 14px;
                    ">
                        {{ \Carbon\Carbon::parse($blog->tanggal_upload)->format('d M Y') }}
                    </div>
                </div>

                <!-- Blog Excerpt -->
                <div style="
                    background: #f8f9fa;
                    padding: 20px;
                    border-radius: 10px;
                    margin-bottom: 30px;
                    border-left: 4px solid #D4A574;
                ">
                    <p style="
                        font-family: 'Inter', sans-serif;
                        font-size: 1.1rem;
                        color: #555;
                        line-height: 1.6;
                        margin: 0;
                        font-style: italic;
                    ">{{ $blog->excerpt }}</p>
                </div>

                <!-- Blog Content -->
                <div style="
                    font-family: 'Inter', sans-serif;
                    color: #333;
                    line-height: 1.8;
                    font-size: 16px;
                ">
                    {!! nl2br(e($blog->content)) !!}
                </div>

                <!-- Blog Footer -->
                <div style="
                    margin-top: 40px;
                    padding-top: 30px;
                    border-top: 1px solid #f0f0f0;
                    text-align: center;
                ">
                    <!-- Back Button -->
                    <a href="{{ route('blogs') }}" style="
                        display: inline-flex;
                        align-items: center;
                        background: #D4A574;
                        color: white;
                        text-decoration: none;
                        padding: 12px 30px;
                        border-radius: 10px;
                        font-family: 'Inter', sans-serif;
                        font-size: 14px;
                        font-weight: 500;
                        transition: background 0.3s ease;
                    " onmouseover="this.style.background='#C19A5F'" onmouseout="this.style.background='#D4A574'">
                        ← Back to Blogs
                    </a>
                </div>
            </div>
        </div>

        <!-- Related Blogs -->
        @if(isset($relatedBlogs) && $relatedBlogs->count() > 0)
        <div style="margin-top: 60px;">
            <h2 style="
                font-family: 'Inter', sans-serif;
                font-size: 1.8rem;
                font-weight: bold;
                color: #2C1810;
                margin: 0 0 30px 0;
                text-align: center;
            ">Artikel Lainnya</h2>
            
            <div style="
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 20px;
            ">
                @foreach($relatedBlogs as $related)
                    <div style="
                        background: white;
                        border-radius: 15px;
                        overflow: hidden;
                        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
                        transition: transform 0.3s ease;
                        cursor: pointer;
                    " onmouseover="this.style.transform='translateY(-5px)'" onmouseout="this.style.transform='translateY(0)'"
                       onclick="window.location.href='{{ route('blogs.show', $related) }}'">
                        <div style="
                            height: 150px;
                            background-size: cover;
                            background-position: center;
                            @if($related->image && file_exists(public_path('storage/' . $related->image)))
                                background-image: url('{{ asset('storage/' . $related->image) }}');
                            @else
                                background-image: url('{{ asset('makanan1.png') }}');
                            @endif
                        "></div>
                        <div style="padding: 20px;">
                            <h3 style="
                                font-family: 'Inter', sans-serif;
                                font-size: 1rem;
                                font-weight: 600;
                                color: #2C1810;
                                margin: 0 0 10px 0;
                                line-height: 1.3;
                            ">{{ $related->judul_blog }}</h3>
                            <p style="
                                color: #666;
                                font-size: 0.9rem;
                                margin: 0;
                                line-height: 1.4;
                            ">{{ Str::limit($related->excerpt, 100) }}</p>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
        @endif
    </div>
</section>

<!-- Responsive Styles -->
<style>
    @media (max-width: 768px) {
        section {
            padding: 100px 0 60px 0 !important;
        }
        
        .blog-content {
            padding: 30px 20px !important;
        }
        
        h1 {
            font-size: 1.5rem !important;
        }
    }
</style>
@endsection
