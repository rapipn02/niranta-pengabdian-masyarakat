<?php

use Illuminate\Support\Facades\Route;
use App\Services\GoogleTranslateService;

Route::get('/debug-translate', function () {
    try {
        $translateService = new GoogleTranslateService();
        
        // Test API key
        $apiKey = env('GOOGLE_TRANSLATE_API_KEY');
        echo "API Key: " . ($apiKey ? "EXISTS (" . substr($apiKey, 0, 10) . "...)" : "NOT SET") . "<br><br>";
        
        // Test translate
        $testText = "Selamat pagi";
        echo "Testing translation...<br>";
        echo "Original: " . $testText . "<br>";
        
        $translated = $translateService->translate($testText, 'en', 'id');
        echo "Translated: " . $translated . "<br><br>";
        
        // Test dengan teks yang berbeda
        $testText2 = "Terima kasih";
        $translated2 = $translateService->translate($testText2, 'en', 'id');
        echo "Original: " . $testText2 . "<br>";
        echo "Translated: " . $translated2 . "<br><br>";
        
        return "Translation test completed!";
        
    } catch (Exception $e) {
        return "Error: " . $e->getMessage() . "<br>Trace: " . $e->getTraceAsString();
    }
});
