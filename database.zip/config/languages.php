<?php

return [
    'id' => 'Indonesian',
    'en' => 'English',
];
