<?php

require_once 'vendor/autoload.php';

$app = require_once 'bootstrap/app.php';
$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use App\Models\Recipe;
use App\Services\GoogleTranslateService;

echo "Testing recipe translation...\n";

$translateService = new GoogleTranslateService();
$recipes = Recipe::all();

echo "Found " . $recipes->count() . " recipes\n";

foreach ($recipes as $recipe) {
    echo "Recipe: {$recipe->nama_resep}\n";
    
    // Translate nama resep
    $translatedName = $translateService->translate($recipe->nama_resep, 'en', 'id');
    echo "Translated name: $translatedName\n";
    
    break; // Just test one
}

echo "Test complete!\n";
