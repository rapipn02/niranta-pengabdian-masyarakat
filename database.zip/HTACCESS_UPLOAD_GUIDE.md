# TUTORIAL UPLOAD FILE .HTACCESS DI HOSTINGER

## Struktur File di Hostinger

Ketika upload ke Hostinger, struktur folder akan seperti ini:

```
public_html/                  ← ROOT domain (yourdomain.com)
├── .htaccess                ← File untuk redirect ke /public
├── app/
├── config/
├── database/
├── public/                  ← Folder Laravel public
│   ├── .htaccess           ← File Laravel bawaan (JANGAN DIUBAH)
│   ├── index.php
│   ├── css/
│   └── js/
├── resources/
├── routes/
└── storage/
```

## Langkah Upload .htaccess

### 1. Upload .htaccess untuk ROOT domain
- **File yang diupload**: `.htaccess.root` atau `.htaccess.production`
- **Lokasi upload**: `public_html/` (ROOT folder)
- **Rename menjadi**: `.htaccess`

### 2. File .htaccess di folder public (BIARKAN APA ADANYA)
- **Lokasi**: `public_html/public/.htaccess`
- **Status**: Sudah ada dan JANGAN DIUBAH
- **Fungsi**: Handle routing Laravel

## Pilihan File .htaccess untuk Root

### Opsi 1: Basic (Cukup untuk hosting biasa)
Gunakan `.htaccess.root`:
```apache
# Redirect ke public folder
RewriteEngine On
RewriteCond %{REQUEST_URI} !^/public/
RewriteRule ^(.*)$ /public/$1 [L,QSA]

# Force HTTPS
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

### Opsi 2: Advanced (Recommended untuk performance)
Gunakan `.htaccess.production`:
```apache
# Semua dari Opsi 1 PLUS:
# - Security headers
# - Cache headers untuk assets
# - Gzip compression
# - Browser caching optimization
```

## Rekomendasi

**Gunakan `.htaccess.production`** untuk performa dan keamanan maksimal!
